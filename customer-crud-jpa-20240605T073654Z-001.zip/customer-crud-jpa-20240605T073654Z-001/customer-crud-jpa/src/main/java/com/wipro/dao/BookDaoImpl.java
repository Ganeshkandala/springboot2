package com.wipro.dao;

import java.util.List;

import com.wipro.entity.Book;
import com.wipro.entity.Customer;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.TypedQuery;

public class BookDaoImpl implements BookDAO{
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("customer-crud-jpa");


	@Override
	public Book getBookById(Integer isbn) {
		
		EntityManager em = null;

		try {
			em = emf.createEntityManager();
			Book book = em.find(Book.class, isbn);
			return book;

		}catch(PersistenceException e) {
			em.close();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Book> getAllBook() {
		EntityManager em = null;
		String jql = " select c from Customer c";
		try {
			em = emf.createEntityManager();
			TypedQuery<Customer> query = em.createQuery(jql,Customer.class);
			List<Customer> customerList = query.getResultList();
			return customerList;
		}catch(PersistenceException e) {
			em.close();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String addBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCustomer(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCustomer(Integer isbn) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.wipro.service;

public interface BookService {

}
